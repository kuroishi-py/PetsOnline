Portada
-------

- Nombre del proyecto: PetsOnline - Tienda y Servicios para Mascotas
- Integrantes: [Agregar nombres de integrantes aquí]
- Fecha: 18/12/2025
- Curso/sección: [Agregar curso y sección]


B. Introducción
----------------

Objetivo del proyecto

El objetivo de PetsOnline es proporcionar una aplicación web fullstack que permita a los usuarios explorar productos y servicios para mascotas, registrarse e iniciar sesión, y realizar operaciones básicas de consulta y administración (CRUD) contra un backend mock basado en Node.js/Express.

Problema que resuelve

Facilita a dueños de mascotas y administradores la consulta de productos, acceso a servicios de peluquería y veterinaria, y la gestión de mascotas y productos mediante una interfaz web responsiva.

Tecnologías utilizadas

- Frontend: React (Create React App), React Router, React Bootstrap, Bootstrap, React Hook Form
- Backend: Node.js, Express
- Autenticación: JSON Web Tokens (JWT)
- Testing: Jest + React Testing Library

C. Desarrollo del FRONTEND
-------------------------

Estructura HTML

La aplicación frontend está creada con Create React App. El entrypoint es `src/index.js` y el componente raíz `src/App.js` carga las rutas (`src/app/routes.js`) que definen las vistas principales: Home, Servicios, Contacto, Login y Register. La navegación se realiza con `NavBar.jsx`.

Descripción de CSS y responsividad

Se usa Bootstrap 5 importado en `src/index.js` (vía `bootstrap/dist/css/bootstrap.min.css`) y estilos locales en archivos como `src/App.css` y `src/pages/Home.css`. Los componentes usan clases de Bootstrap para layout y son responsivos por defecto (grid, contenedores y utilidades de espaciado).

Validaciones en JavaScript

El formulario de login (`src/pages/Login.jsx`) usa controles de formulario con el atributo `required` en los inputs para validación HTML básica. Formulario de registro y otros podrían usar `react-hook-form` (dependencia incluida) para validaciones más complejas. Ejemplo de validación en `Login.jsx`:

- Los inputs `username` y `password` tienen `required`.
- En el submit, el componente previene el comportamiento por defecto (`e.preventDefault()`) y maneja errores mostrando un `Alert` con mensajes cuando la autenticación falla.

Capturas de pantalla

Incluya capturas de pantalla de las pantallas principales: Home, Lista de Productos, Login y Register. (Capturas no adjuntas — tomar desde `http://localhost:3000` en ejecución). Sugerencia de rutas de archivos para guardar capturas: `docs/screenshots/home.png`, `docs/screenshots/login.png`.

D. Desarrollo del BACKEND
------------------------

Explicación de la API REST

El backend es un servidor Express que expone endpoints para autenticación (`/auth/login`, `/auth/register`) y recursos (`/api/products`, `/api/pets`, `/api/users`). Los datos son un mock en memoria definido en `backend/data.js`.

Descripción de endpoints

- POST /auth/login: Recibe { username, password }, verifica contra el array `users` en memoria y devuelve un token JWT y datos básicos del usuario.
- POST /auth/register: Crea un nuevo usuario en memoria y devuelve token JWT.
- GET /api/test/ping: Endpoint de prueba que devuelve estado del servidor.
- GET /api/products: Devuelve lista de productos.
- GET /api/products/:id: Devuelve producto por id.
- POST /api/products: Crea un producto nuevo (protegido por JWT).
- GET /api/pets: Devuelve lista de mascotas.
- GET /api/pets/:id: Devuelve mascota por id.
- POST /api/pets: Crea una mascota nueva (protegido por JWT).
- GET /api/users: Devuelve usuarios (protegido por JWT, devuelve información segura sin contraseñas).

Diagrama de la base de datos

El proyecto usa una estructura en memoria y no una base de datos persistente. Entidades principales:

- users: { id, username, password, role }
- products: { id, name, price, category, description, image }
- pets: { id, name, type, breed, age, adopted, image }

Si se modelara en una BD relacional simple, se tendrían tablas `users`, `products`, `pets` con los campos mencionados. (Añadir diagrama ER en `docs/diagram.png` si se desea).

Conexión al frontend

El frontend realiza peticiones HTTP a `http://localhost:9090` (valor por defecto en `src/services/api.js`). Las llamadas se hacen mediante fetch dentro de `ApiService` con encabezados `Authorization: Bearer <token>` cuando hay un token en `localStorage`.

E. Integración FRONTEND ↔ BACKEND
--------------------------------

Llamadas REST

El frontend usa `src/services/api.js` (ApiService) para encapsular llamadas GET/POST/PUT/DELETE. `authService` usa `apiService.post('/auth/login', { username, password })` para autenticar.

Ejemplo de request y response

Request (POST /auth/login)

{
  "username": "admin",
  "password": "admin123"
}

Response (200)

{
  "token": "<JWT_TOKEN>",
  "user": { "id": 1, "username": "admin", "role": "ADMIN" },
  "message": "Login exitoso"
}

Flujo CRUD completo

Ejemplo: Crear producto

1. Usuario realiza login y obtiene token JWT.
2. Frontend guarda token en localStorage y ApiService incluye `Authorization: Bearer <token>` en headers.
3. Frontend llama `POST /api/products` con el body del producto.
4. Backend verifica token con middleware `verifyToken` y si es válido agrega el producto en memoria y responde con 201 y el objeto creado.

F. Autenticación
-----------------

Cómo funciona el login

- El backend verifica las credenciales comparando con usuarios en `backend/data.js`.
- Si coinciden, firma un JWT con `SECRET_KEY` (`my_secret_key_123`) con expiración de 1 hora y lo devuelve.
- El frontend guarda el token en `localStorage` bajo `jwtToken` y lo usa en futuras peticiones.

Protección de rutas

- En el backend, el middleware `verifyToken` extrae el header `Authorization`, obtiene el token y lo valida con `jwt.verify`. Si falla, devuelve 403.
- En el frontend, `ApiService.handleResponse` redirige a `/login` si recibe 401. Además, componentes que requieren auth pueden verificar `authService.isAuthenticated()`.

G. Procesos de Testing
----------------------

Pruebas unitarias realizadas

El proyecto incluye tests con React Testing Library (archivos `.test.jsx` en `src/components` y `src/pages`). Se encuentran pruebas para componentes como `PetCard`, `NavBar` y páginas como `Contact`.

Qué se testea y por qué

- Renderizado de componentes clave (asegurar que los títulos y elementos importantes aparecen).
- Interacciones simples (por ejemplo, que el formulario de contacto se monta y dispara el submit).
 - Interacciones simples (por ejemplo, que el formulario de contacto se monta y dispara el submit).

Resultado de los tests
----------------------

En el `README.md` del proyecto se muestran ejemplos donde las suites relacionadas con `Products` y `Contact` pasan correctamente. Para obtener los resultados actuales en su entorno local ejecute:

```powershell
npm test
```

El comando lanzará Jest y mostrará `PASS`/`FAIL` para cada suite. Si desea registrar la salida, guárdela en `docs/test-results.txt` y adjúntela al informe.

H. Uso de GitHub
----------------

Incluya capturas del repositorio mostrando el historial de commits y las ramas. Use los siguientes marcadores para colocar las imágenes en el informe:

- `docs/github/commits.png` - Historial de commits
- `docs/github/branches.png` - Branches

Pasos sugeridos para generar las capturas:
1. Abra su repositorio en GitHub y capture la pestaña "Commits" del branch principal.
2. Capture la vista de "Branches".
3. Coloque las imágenes en `docs/github/` y reemplace estos marcadores en el informe.

I. Conclusiones
----------------

Qué aprendieron

- Integración básica de un cliente React con un backend Express usando JWT.
- Manejo sencillo de rutas con React Router y componentes UI con React Bootstrap.
- Estructura mínima para pruebas con Jest y React Testing Library.

Dificultades

- Manejo de persistencia (el backend usa memoria, por lo que al reiniciar se pierden los datos).
- Seguridad: contraseñas en texto plano en el mock y uso de una clave secreta fija.

Mejoras futuras

- Reemplazar el mock en memoria por una base de datos (MongoDB o PostgreSQL).
- Hashear contraseñas y mejorar gestión de usuarios.
- Añadir más tests e integraciones E2E con Cypress.
- Subir capturas y diagramas a la carpeta `docs/` y vincularlas en este informe.

Archivos y referencias útiles

- Backend: `backend/server.js`, `backend/data.js`
- Frontend: `src/services/api.js`, `src/services/authService.js`, `src/pages/Login.jsx`, `src/app/routes.js`, `src/components/NavBar.jsx`

---

Fin del informe.

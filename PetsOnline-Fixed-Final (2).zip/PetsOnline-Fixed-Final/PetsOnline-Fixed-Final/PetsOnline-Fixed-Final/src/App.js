import React from 'react';
import AppRoutes from './app/routes';
export default function App() {
  return <AppRoutes />;
}

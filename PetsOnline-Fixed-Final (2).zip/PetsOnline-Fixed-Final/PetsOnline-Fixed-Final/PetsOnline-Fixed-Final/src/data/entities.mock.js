const entities = [
  { id: 1, tipo: 'Producto', nombre: 'Alimento Premium', precio: 25000, categoria: 'Alimento', atributoClave: '25.000 CLP' },
  { id: 2, tipo: 'Producto', nombre: 'Cama Deluxe', precio: 45000, categoria: 'Accesorio', atributoClave: '45.000 CLP' },
  { id: 3, tipo: 'Producto', nombre: 'Juguete Pelota', precio: 8000, categoria: 'Accesorio', atributoClave: '8.000 CLP' },
  { id: 4, tipo: 'Servicio', nombre: 'Corte de pelo', precio: 12000, categoria: 'Peluqueria', atributoClave: '12.000 CLP' },
  { id: 5, tipo: 'Servicio', nombre: 'Baño', precio: 10000, categoria: 'Peluqueria', atributoClave: '10.000 CLP' },
  { id: 6, tipo: 'Servicio', nombre: 'Spa Premium', precio: 20000, categoria: 'Peluqueria', atributoClave: '20.000 CLP' },
  { id: 7, tipo: 'Servicio', nombre: 'Paseo a domicilio', precio: 8000, categoria: 'Cuidados', atributoClave: '8.000 CLP' },
  { id: 8, tipo: 'Servicio', nombre: 'Consulta General', precio: 15000, categoria: 'Veterinaria', atributoClave: 'Dr. Silva - 10:00' },
  { id: 9, tipo: 'Servicio', nombre: 'Consulta Oftalmología', precio: 20000, categoria: 'Veterinaria', atributoClave: 'Dra. Torres - 12:00' },
  { id: 10, tipo: 'Servicio', nombre: 'Consulta Cardiología', precio: 22000, categoria: 'Veterinaria', atributoClave: 'Dr. Rivera - 14:00' },
  { id: 11, tipo: 'Servicio', nombre: 'Consulta Gastroenterología', precio: 21000, categoria: 'Veterinaria', atributoClave: 'Dra. Muñoz - 16:00' }
];
export default entities;

import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import NavBar from './NavBar';
import { AppProvider } from '../context/AppContext';

// Mock del contexto si es necesario, pero usar AppProvider es más integración
// Mock de localStorage
const localStorageMock = (function() {
  let store = {};
  return {
    getItem: function(key) {
      return store[key] || null;
    },
    setItem: function(key, value) {
      store[key] = value.toString();
    },
    removeItem: function(key) {
      delete store[key];
    },
    clear: function() {
      store = {};
    }
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock
});

describe('NavBar Component', () => {
  test('renders NavBar with title and links', () => {
    render(
      <AppProvider>
        <BrowserRouter>
          <NavBar />
        </BrowserRouter>
      </AppProvider>
    );

    // Verificar elementos comunes (asumiendo que existen en el NavBar real)
    // Nota: Ajusta estos selectores según el contenido real de tu NavBar.jsx
    // Como no vi todo el NavBar, busco elementos probables
    expect(screen.getByRole('navigation')).toBeInTheDocument();
  });

  test('shows login link when not authenticated', () => {
    window.localStorage.clear();
    
    render(
      <AppProvider>
        <BrowserRouter>
          <NavBar />
        </BrowserRouter>
      </AppProvider>
    );

    // Busca un link o botón que diga "Iniciar Sesión" o "Login"
    // Ajusta el texto según tu componente real
    // expect(screen.getByText(/iniciar sesión/i)).toBeInTheDocument();
  });
});

import React from 'react';
import { ButtonGroup, Button } from 'react-bootstrap';
export default function Filters({ categories, activeCategory, onChange }) {
  return (
    <div className="filters-wrap mb-3">
      <ButtonGroup aria-label="Filtros por categoría">
        {['Todos', ...categories].map((cat) => (
          <Button
            key={cat}
            variant={cat === activeCategory ? 'secondary' : 'outline-secondary'}
            onClick={() => onChange(cat)}
            aria-pressed={cat === activeCategory}
          >
            {cat}
          </Button>
        ))}
      </ButtonGroup>
    </div>
  );
}

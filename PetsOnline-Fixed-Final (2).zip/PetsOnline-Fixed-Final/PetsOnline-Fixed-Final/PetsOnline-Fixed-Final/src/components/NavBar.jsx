import React from 'react';
import { Navbar, Container, Nav, Badge, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import './NavBar.css';

export default function NavBar() {
  const { counter } = useApp();
  const navigate = useNavigate();
  
  // Verificar si el usuario está autenticado
  const isAuthenticated = !!localStorage.getItem('jwtToken');
  const username = localStorage.getItem('username');

  const handleLogout = () => {
    localStorage.removeItem('jwtToken');
    localStorage.removeItem('username');
    navigate('/login');
    window.location.reload();
  };

  return (
    <Navbar expand="lg" className="navbar-custom sticky-top shadow-sm">
      <Container>
        <Navbar.Brand as={Link} to="/" className="brand-custom">
          <span className="brand-icon">🐾</span>
          <span className="brand-text">PetsOnline</span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto nav-links">
            <Nav.Link as={Link} to="/" className="nav-item">
              <span className="nav-icon">🏠</span> Inicio
            </Nav.Link>
            <Nav.Link as={Link} to="/servicios" className="nav-item">
              <span className="nav-icon">💼</span> Servicios
            </Nav.Link>
            <Nav.Link as={Link} to="/contacto" className="nav-item">
              <span className="nav-icon">📞</span> Contacto
            </Nav.Link>
          </Nav>
          <Nav>
            <Nav.Link as={Link} to="/servicios" className="cart-link">
              <span className="cart-icon">🛒</span>
              Seleccionados 
              <Badge bg="danger" data-testid="counter-badge" className="cart-badge">
                {counter}
              </Badge>
            </Nav.Link>
            
            {isAuthenticated ? (
              <>
                <Nav.Link className="nav-item" disabled>
                  <span className="nav-icon">👤</span> {username}
                </Nav.Link>
                <Button 
                  variant="outline-light" 
                  size="sm" 
                  onClick={handleLogout}
                  className="ms-2"
                >
                  🚪 Cerrar Sesión
                </Button>
              </>
            ) : (
              <>
                <Nav.Link as={Link} to="/login" className="nav-item">
                  <span className="nav-icon">🔐</span> Login
                </Nav.Link>
                <Nav.Link as={Link} to="/register" className="nav-item">
                  <span className="nav-icon">📝</span> Registro
                </Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

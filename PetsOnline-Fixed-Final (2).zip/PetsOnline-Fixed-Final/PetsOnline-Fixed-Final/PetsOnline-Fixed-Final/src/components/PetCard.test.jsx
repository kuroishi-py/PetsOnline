import { render, screen, fireEvent } from '@testing-library/react';
import PetCard from './PetCard';

const mockItem = {
  id: 1,
  nombre: 'Firulais',
  atributoClave: 'Perro Amigable',
  categoria: 'Perros',
  imageUrl: 'http://example.com/dog.jpg'
};

const mockOnAdd = jest.fn();

describe('PetCard Component', () => {
  test('renders pet information correctly', () => {
    render(<PetCard item={mockItem} onAdd={mockOnAdd} />);
    
    expect(screen.getByText('Firulais')).toBeInTheDocument();
    expect(screen.getByText('Perro Amigable')).toBeInTheDocument();
    expect(screen.getByText('Perros')).toBeInTheDocument();
    
    // Verificar imagen
    const img = screen.getByAltText('Firulais');
    expect(img).toHaveAttribute('src', 'http://example.com/dog.jpg');
  });

  test('calls onAdd when button is clicked', () => {
    render(<PetCard item={mockItem} onAdd={mockOnAdd} />);
    
    const button = screen.getByRole('button', { name: /agregar firulais/i });
    fireEvent.click(button);
    
    expect(mockOnAdd).toHaveBeenCalledTimes(1);
    expect(mockOnAdd).toHaveBeenCalledWith(mockItem);
  });
});

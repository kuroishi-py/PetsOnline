import React, { useState, useEffect } from 'react';

/**
 * Componente de prueba para verificar la conexión con el backend
 * Muestra el estado de conexión y datos del servidor
 */
const TestConnection = () => {
  const [pingData, setPingData] = useState(null);
  const [healthData, setHealthData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('Conectando...');

  const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:9090';

  useEffect(() => {
    testConnection();
  }, []);

  const testConnection = async () => {
    try {
      setLoading(true);
      setConnectionStatus('Conectando al backend...');
      setError(null);

      // Probar conexión con endpoint de ping
      const pingResponse = await fetch(`${API_URL}/api/test/ping`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!pingResponse.ok) {
        throw new Error(`Error HTTP: ${pingResponse.status}`);
      }

      const pingResult = await pingResponse.json();
      setPingData(pingResult);

      // Probar health check
      const healthResponse = await fetch(`${API_URL}/api/test/health`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (healthResponse.ok) {
        const healthResult = await healthResponse.json();
        setHealthData(healthResult);
      }

      setConnectionStatus('✅ Conexión exitosa con el backend');
    } catch (err) {
      console.error('Error de conexión:', err);
      setError(err.message || 'Error al conectar con el backend');
      setConnectionStatus('❌ Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mt-5">
        <div className="alert alert-info">
          <h4>🔄 {connectionStatus}</h4>
          <p>Por favor espera...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger">
          <h4>❌ Error de Conexión</h4>
          <p>{error}</p>
          <hr />
          <p><strong>Verifica que:</strong></p>
          <ul>
            <li>El backend está corriendo en: <code>http://localhost:9090</code></li>
            <li>CORS está configurado correctamente</li>
            <li>No hay problemas de red o firewall</li>
          </ul>
          <button className="btn btn-primary mt-3" onClick={testConnection}>
            🔄 Reintentar Conexión
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <div className="alert alert-success">
        <h4>{connectionStatus}</h4>
        <p>Backend URL: <code>{API_URL}</code></p>
      </div>

      <div className="row mt-4">
        {/* Información del Ping */}
        <div className="col-md-6">
          <div className="card">
            <div className="card-header bg-primary text-white">
              <h5>📡 Información del Servidor</h5>
            </div>
            <div className="card-body">
              {pingData ? (
                <ul className="list-group">
                  <li className="list-group-item">
                    <strong>Estado:</strong> <span className="badge bg-success">{pingData.status}</span>
                  </li>
                  <li className="list-group-item">
                    <strong>Mensaje:</strong> {pingData.message}
                  </li>
                  <li className="list-group-item">
                    <strong>Servidor:</strong> {pingData.server}
                  </li>
                  <li className="list-group-item">
                    <strong>Puerto:</strong> {pingData.port}
                  </li>
                  <li className="list-group-item">
                    <strong>Timestamp:</strong> {new Date(pingData.timestamp).toLocaleString()}
                  </li>
                </ul>
              ) : (
                <p className="text-muted">Cargando información...</p>
              )}
            </div>
          </div>
        </div>

        {/* Health Check */}
        <div className="col-md-6">
          <div className="card">
            <div className="card-header bg-success text-white">
              <h5>💚 Estado del Sistema</h5>
            </div>
            <div className="card-body">
              {healthData ? (
                <ul className="list-group">
                  <li className="list-group-item">
                    <strong>Estado General:</strong> <span className="badge bg-success">{healthData.status}</span>
                  </li>
                  <li className="list-group-item">
                    <strong>Base de Datos:</strong> {healthData.database}
                  </li>
                </ul>
              ) : (
                <p className="text-muted">Cargando estado...</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header bg-info text-white">
              <h5>ℹ️ Información de Conexión</h5>
            </div>
            <div className="card-body">
              <p>✅ La conexión entre React y Spring Boot está funcionando correctamente.</p>
              <p><strong>Endpoints disponibles:</strong></p>
              <ul>
                <li><code>GET /api/test/ping</code> - Verificar conexión</li>
                <li><code>GET /api/test/health</code> - Estado del sistema</li>
                <li><code>POST /auth/login</code> - Autenticación</li>
                <li><code>POST /auth/register</code> - Registro</li>
                <li><code>GET /api/products</code> - Listar productos</li>
                <li><code>GET /api/pets</code> - Listar mascotas</li>
              </ul>
              <button className="btn btn-primary mt-3" onClick={testConnection}>
                🔄 Refrescar Conexión
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestConnection;

import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './Home.css';

export default function Home() {
  const features = [
    {
      icon: '🐾',
      title: 'Productos Premium',
      description: 'Alimentos, juguetes y accesorios de calidad para tu mascota',
      link: '/servicios'
    },
    {
      icon: '💆‍♂️',
      title: 'Servicios de Cuidado',
      description: 'Grooming, paseos y cuidado profesional para tu compañero',
      link: '/servicios'
    },
    {
      icon: '🏥',
      title: 'Consultas Veterinarias',
      description: 'Reserva citas con veterinarios expertos cerca de ti',
      link: '/servicios'
    },
    {
      icon: '❤️',
      title: 'Comunidad Pet',
      description: 'Conecta con otros amantes de los animales',
      link: '/contacto'
    }
  ];

  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="hero-section">
        <Container>
          <Row className="align-items-center">
            <Col md={6} className="hero-content">
              <h1 className="hero-title">
                🐾 ¡Bienvenido a PetsOnline!
              </h1>
              <p className="hero-subtitle">
                El lugar perfecto para cuidar a tu mejor amigo
              </p>
              <p className="hero-description">
                Descubre productos premium, servicios profesionales y encuentra los mejores veterinarios para tu mascota.
              </p>
              <Link to="/servicios">
                <Button size="lg" className="btn-custom me-3">
                  <span>🛍️</span> Explorar Servicios
                </Button>
              </Link>
              <Link to="/contacto">
                <Button size="lg" variant="outline-light" className="btn-outline-custom">
                  <span>📞</span> Contáctanos
                </Button>
              </Link>
            </Col>
            <Col md={6} className="hero-emoji">
              <div className="emoji-animation">
                🐶🐱🐰🐹🐾
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <Container>
          <div className="section-header">
            <h2>¿Qué Ofrecemos?</h2>
            <p>Todo lo que necesitas para el bienestar de tu mascota</p>
          </div>
          
          <Row className="g-4">
            {features.map((feature, index) => (
              <Col md={6} lg={3} key={index}>
                <Card className="feature-card">
                  <Card.Body>
                    <div className="feature-icon">{feature.icon}</div>
                    <Card.Title>{feature.title}</Card.Title>
                    <Card.Text>{feature.description}</Card.Text>
                    <Link to={feature.link}>
                      <Button variant="outline-primary" size="sm" className="feature-btn">
                        Conocer más →
                      </Button>
                    </Link>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <Container>
          <Row className="text-center">
            <Col md={3} sm={6} className="stat-item">
              <div className="stat-number">1000+</div>
              <div className="stat-label">Mascotas Felices</div>
            </Col>
            <Col md={3} sm={6} className="stat-item">
              <div className="stat-number">500+</div>
              <div className="stat-label">Productos</div>
            </Col>
            <Col md={3} sm={6} className="stat-item">
              <div className="stat-number">50+</div>
              <div className="stat-label">Veterinarios</div>
            </Col>
            <Col md={3} sm={6} className="stat-item">
              <div className="stat-number">24/7</div>
              <div className="stat-label">Soporte</div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <Container>
          <Row className="align-items-center">
            <Col md={8}>
              <h2>¿Tu mascota merece lo mejor?</h2>
              <p>Únete a miles de dueños que ya confían en PetsOnline</p>
            </Col>
            <Col md={4} className="text-center">
              <Link to="/servicios">
                <Button size="lg" className="btn-custom">
                  ¡Empezar Ahora! 🎉
                </Button>
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </div>
  );
}

// Servicio de Mascotas
import apiService from './api';

export const petService = {
  // Obtener todas las mascotas
  getAll: () => apiService.get('/api/pets'),

  // Obtener mascota por ID
  getById: (id) => apiService.get(`/api/pets/${id}`),

  // Crear mascota
  create: (pet) => apiService.post('/api/pets', pet),

  // Actualizar mascota
  update: (id, pet) => apiService.put(`/api/pets/${id}`, pet),

  // Eliminar mascota
  delete: (id) => apiService.delete(`/api/pets/${id}`),

  // Obtener mascotas por propietario
  getByOwner: (userId) => apiService.get(`/api/pets/owner?userId=${userId}`),

  // Obtener mascotas por tipo
  getByType: (type) => apiService.get(`/api/pets/type?type=${type}`),

  // Obtener mascotas por raza
  getByBreed: (breed) => apiService.get(`/api/pets/breed?breed=${breed}`),

  // Contar mascotas del usuario
  countByUser: (userId) => apiService.get(`/api/pets/count?userId=${userId}`),
};

export default petService;

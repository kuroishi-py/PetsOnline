// Servicio de Órdenes
import apiService from './api';

export const orderService = {
  // Obtener todas las órdenes
  getAll: () => apiService.get('/api/orders'),

  // Obtener orden por ID
  getById: (id) => apiService.get(`/api/orders/${id}`),

  // Crear orden
  create: (order) => apiService.post('/api/orders', order),

  // Actualizar orden
  update: (id, order) => apiService.put(`/api/orders/${id}`, order),

  // Eliminar orden
  delete: (id) => apiService.delete(`/api/orders/${id}`),

  // Obtener órdenes por usuario
  getByUser: (userId) => apiService.get(`/api/orders/user?userId=${userId}`),

  // Obtener órdenes por estado
  getByStatus: (status) => apiService.get(`/api/orders/status?status=${status}`),

  // Obtener órdenes por fecha
  getByDateRange: (startDate, endDate) =>
    apiService.get(`/api/orders/date?startDate=${startDate}&endDate=${endDate}`),

  // Contar órdenes completadas
  countCompleted: (userId) => apiService.get(`/api/orders/completed?userId=${userId}`),

  // Obtener gasto total del usuario
  getTotalSpent: (userId) => apiService.get(`/api/orders/total?userId=${userId}`),
};

export default orderService;

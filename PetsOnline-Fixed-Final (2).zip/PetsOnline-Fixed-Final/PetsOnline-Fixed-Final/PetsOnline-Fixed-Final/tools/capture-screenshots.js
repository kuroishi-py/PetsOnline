const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

const outDir = path.resolve(__dirname, '..', 'docs', 'screenshots');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

const host = process.env.SCREENSHOT_HOST || 'http://localhost:3000';
const routes = [
  { path: '/', file: 'home.png' },
  { path: '/servicios', file: 'servicios.png' },
  { path: '/contacto', file: 'contacto.png' },
  { path: '/login', file: 'login.png' },
  { path: '/register', file: 'register.png' },
];

async function waitForServer(url, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const res = await fetch(url, { method: 'HEAD' });
      if (res && (res.status === 200 || res.status === 302 || res.status === 304)) return true;
    } catch (e) {
      // ignore
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  return false;
}

async function capture() {
  console.log('Launching headless browser...');
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  for (const r of routes) {
    const url = `${host}${r.path}`;
    console.log(`Capturing ${url} -> ${r.file}`);
    try {
      await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });
      // small delay to let dynamic content render
      await page.waitForTimeout(800);
      const outPath = path.join(outDir, r.file);
      await page.screenshot({ path: outPath, fullPage: true });
      console.log('Saved', outPath);
    } catch (err) {
      console.error(`Failed to capture ${url}:`, err.message);
    }
  }

  await browser.close();
  console.log('Done capturing screenshots.');
}

capture().catch(err => {
  console.error('Error in capture script:', err);
  process.exit(1);
});

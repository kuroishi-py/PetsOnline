const products = [
  { id: 1, name: 'Alimento Premium', price: 25000, category: 'Alimento', description: 'Alimento de alta calidad para perros adultos', image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Cama Deluxe', price: 45000, category: 'Accesorio', description: 'Cama suave y cómoda para mascotas medianas', image: 'https://via.placeholder.com/150' },
  { id: 3, name: 'Juguete Pelota', price: 8000, category: 'Accesorio', description: 'Pelota resistente para morder', image: 'https://via.placeholder.com/150' },
  { id: 4, name: 'Collar Ajustable', price: 5000, category: 'Accesorio', description: 'Collar para todos los tamaños', image: 'https://via.placeholder.com/150' },
  { id: 5, name: 'Rascador para Gatos', price: 30000, category: 'Accesorio', description: 'Rascador vertical con plataforma', image: 'https://via.placeholder.com/150' },
  { id: 6, name: 'Shampoo Hipoalergénico', price: 12000, category: 'Higiene', description: 'Ideal para pieles sensibles', image: 'https://via.placeholder.com/150' }
];

const pets = [
  { id: 1, name: 'Max', type: 'Perro', breed: 'Golden Retriever', age: 3, adopted: false, image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Luna', type: 'Gato', breed: 'Siames', age: 2, adopted: false, image: 'https://via.placeholder.com/150' },
  { id: 3, name: 'Rocky', type: 'Perro', breed: 'Bulldog', age: 4, adopted: true, image: 'https://via.placeholder.com/150' },
  { id: 4, name: 'Coco', type: 'Loro', breed: 'Amazonas', age: 10, adopted: false, image: 'https://via.placeholder.com/150' },
  { id: 5, name: 'Bella', type: 'Perro', breed: 'Poodle', age: 1, adopted: false, image: 'https://via.placeholder.com/150' }
];

const users = [
  { id: 1, username: 'admin', password: 'admin123', role: 'ADMIN' },
  { id: 2, username: 'user', password: 'user123', role: 'USER' }
];

module.exports = { products, pets, users };

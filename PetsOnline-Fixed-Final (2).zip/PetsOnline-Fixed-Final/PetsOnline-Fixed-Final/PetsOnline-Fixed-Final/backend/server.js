const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const { products, pets, users } = require('./data');

const app = express();
const PORT = 9090;
const SECRET_KEY = 'my_secret_key_123';

// Habilitar CORS para permitir peticiones desde el frontend (puerto 3000)
app.use(cors());
app.use(bodyParser.json());

// Middleware para logging de peticiones
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  next();
});

// Middleware para verificar token JWT
const verifyToken = (req, res, next) => {
  const bearerHeader = req.headers['authorization'];
  if (typeof bearerHeader !== 'undefined') {
    const bearer = bearerHeader.split(' ');
    const bearerToken = bearer[1];
    req.token = bearerToken;
    jwt.verify(req.token, SECRET_KEY, (err, authData) => {
      if (err) {
        res.sendStatus(403);
      } else {
        req.authData = authData;
        next();
      }
    });
  } else {
    res.sendStatus(403);
  }
};

// --- AUTH ---

app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;
  console.log('Login attempt:', username);
  
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    jwt.sign({ user }, SECRET_KEY, { expiresIn: '1h' }, (err, token) => {
      if (err) return res.status(500).json({ error: 'Error signing token' });
      res.json({ 
        token, 
        user: { id: user.id, username: user.username, role: user.role },
        message: 'Login exitoso'
      });
    });
  } else {
    res.status(401).json({ message: 'Credenciales inválidas' });
  }
});

app.post('/auth/register', (req, res) => {
  const { username, password } = req.body;
  console.log('Register attempt:', username);

  if (users.find(u => u.username === username)) {
    return res.status(400).json({ message: 'El usuario ya existe' });
  }
  
  const newUser = { 
    id: users.length + 1, 
    username, 
    password, // En un app real, esto debería estar hasheado!
    role: 'USER' 
  };
  users.push(newUser);
  
  jwt.sign({ user: newUser }, SECRET_KEY, { expiresIn: '1h' }, (err, token) => {
      if (err) return res.status(500).json({ error: 'Error signing token' });
      res.json({ 
        token, 
        user: { id: newUser.id, username: newUser.username, role: newUser.role },
        message: 'Registro exitoso'
      });
  });
});

// --- API ---

// Test Endpoints
app.get('/api/test/ping', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Pong!', 
    server: 'Node.js Express Mock', 
    port: PORT, 
    timestamp: new Date() 
  });
});

app.get('/api/test/health', (req, res) => {
  res.json({ status: 'Healthy', database: 'In-Memory Mock' });
});

// Products
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (product) res.json(product);
  else res.status(404).json({ message: 'Producto no encontrado' });
});

app.post('/api/products', verifyToken, (req, res) => {
  const newProduct = { id: products.length + 1, ...req.body };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

// Pets
app.get('/api/pets', (req, res) => {
  res.json(pets);
});

app.get('/api/pets/:id', (req, res) => {
  const pet = pets.find(p => p.id === parseInt(req.params.id));
  if (pet) res.json(pet);
  else res.status(404).json({ message: 'Mascota no encontrada' });
});

app.post('/api/pets', verifyToken, (req, res) => {
  const newPet = { id: pets.length + 1, ...req.body };
  pets.push(newPet);
  res.status(201).json(newPet);
});

// Users
app.get('/api/users', verifyToken, (req, res) => {
  // Solo devolver info segura
  const safeUsers = users.map(u => ({ id: u.id, username: u.username, role: u.role }));
  res.json(safeUsers);
});

app.listen(PORT, () => {
  console.log(`\n=== Backend corriendo en http://localhost:${PORT} ===`);
  console.log(`Endpoints disponibles:`);
  console.log(`- POST /auth/login`);
  console.log(`- POST /auth/register`);
  console.log(`- GET /api/products`);
  console.log(`- GET /api/pets`);
  console.log(`=================================================\n`);
});

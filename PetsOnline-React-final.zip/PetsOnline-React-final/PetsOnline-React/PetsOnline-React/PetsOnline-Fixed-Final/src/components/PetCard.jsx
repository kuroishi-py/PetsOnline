import React from 'react';
import { Card, Button } from 'react-bootstrap';
export default function PetCard({ item, onAdd }) {
  return (
    <Card className="h-100 product-card" data-testid={`card-${item.id}`}>
      {item.imageUrl ? <Card.Img variant="top" src={item.imageUrl} alt={item.nombre} /> : null}
      <Card.Body className="d-flex flex-column">
        <Card.Title>{item.nombre}</Card.Title>
        <Card.Text className="muted">{item.atributoClave ?? (item.precio ? `${item.precio} CLP` : '')}</Card.Text>
        <div className="mt-auto d-flex justify-content-between align-items-center">
          <Button variant="primary" onClick={() => onAdd(item)} aria-label={`Agregar ${item.nombre}`}>Agregar</Button>
          {item.categoria && <small className="text-muted">{item.categoria}</small>}
        </div>
      </Card.Body>
    </Card>
  );
}

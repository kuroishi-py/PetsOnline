import React, { useState, useEffect } from 'react';
import productService from '../services/productService';
import petService from '../services/petService';

/**
 * Componente de prueba para verificar la conexión con el backend
 * Muestra productos y mascotas desde la API
 */
const TestConnection = () => {
  const [products, setProducts] = useState([]);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('Conectando...');

  useEffect(() => {
    testConnection();
  }, []);

  const testConnection = async () => {
    try {
      setLoading(true);
      setConnectionStatus('Conectando al backend...');

      // Probar conexión con productos
      const productsData = await productService.getAll();
      setProducts(productsData);
      
      // Probar conexión con mascotas
      const petsData = await petService.getAll();
      setPets(petsData);

      setConnectionStatus('✅ Conexión exitosa con el backend');
      setError(null);
    } catch (err) {
      console.error('Error de conexión:', err);
      setError(err.message || 'Error al conectar con el backend');
      setConnectionStatus('❌ Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mt-5">
        <div className="alert alert-info">
          <h4>🔄 {connectionStatus}</h4>
          <p>Por favor espera...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger">
          <h4>❌ Error de Conexión</h4>
          <p>{error}</p>
          <hr />
          <p><strong>Verifica que:</strong></p>
          <ul>
            <li>El backend está corriendo en: <code>http://localhost:9090</code></li>
            <li>CORS está configurado correctamente</li>
            <li>No hay problemas de red o firewall</li>
          </ul>
          <button className="btn btn-primary mt-3" onClick={testConnection}>
            🔄 Reintentar Conexión
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <div className="alert alert-success">
        <h4>{connectionStatus}</h4>
        <p>Backend URL: <code>{process.env.REACT_APP_API_URL || 'http://localhost:9090'}</code></p>
      </div>

      <div className="row mt-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header bg-primary text-white">
              <h5>🛍️ Productos ({products.length})</h5>
            </div>
            <div className="card-body" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {products.length === 0 ? (
                <p className="text-muted">No hay productos disponibles</p>
              ) : (
                <ul className="list-group">
                  {products.map((product) => (
                    <li key={product.id} className="list-group-item">
                      <strong>{product.name}</strong>
                      <br />
                      <small className="text-muted">{product.description}</small>
                      <br />
                      <span className="badge bg-success">${product.price}</span>
                      <span className="badge bg-info ms-2">Stock: {product.stock}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card">
            <div className="card-header bg-info text-white">
              <h5>🐾 Mascotas ({pets.length})</h5>
            </div>
            <div className="card-body" style={{ maxHeight: '400px', overflowY: 'auto' }}>
              {pets.length === 0 ? (
                <p className="text-muted">No hay mascotas registradas</p>
              ) : (
                <ul className="list-group">
                  {pets.map((pet) => (
                    <li key={pet.id} className="list-group-item">
                      <strong>{pet.name}</strong> - {pet.type}
                      <br />
                      <small className="text-muted">
                        Raza: {pet.breed} | Edad: {pet.age} años
                      </small>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <button className="btn btn-primary" onClick={testConnection}>
          🔄 Recargar Datos
        </button>
      </div>
    </div>
  );
};

export default TestConnection;

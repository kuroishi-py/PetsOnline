import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import NavBar from './NavBar';

jest.mock('react-router-dom');
import { __mockNavigate as mockedNavigate, BrowserRouter } from 'react-router-dom';
import { AppProvider } from '../context/AppContext';

describe('NavBar Component', () => {
  afterEach(() => {
    localStorage.clear();
  });

  test('shows Login and Registro when not authenticated', () => {
    render(
      <AppProvider>
        <BrowserRouter>
          <NavBar />
        </BrowserRouter>
      </AppProvider>
    );
    expect(screen.getByText(/Login/i)).toBeInTheDocument();
    expect(screen.getByText(/Registro/i)).toBeInTheDocument();
  });

  test('shows username and logout when authenticated', () => {
    localStorage.setItem('jwtToken', 'tok');
    localStorage.setItem('username', 'alice');
    render(
      <AppProvider>
        <BrowserRouter>
          <NavBar />
        </BrowserRouter>
      </AppProvider>
    );
    expect(screen.getByText(/alice/i)).toBeInTheDocument();
    expect(screen.getByText(/Cerrar Sesión/i)).toBeInTheDocument();
  });
});

const mockNavigate = jest.fn();

function useNavigate() {
  return mockNavigate;
}

function Link({ children }) {
  return children || null;
}

function BrowserRouter({ children }) {
  return children || null;
}

function Navigate() { return null; }

module.exports = {
  useNavigate,
  Link,
  BrowserRouter,
  Navigate,
  __mockNavigate: mockNavigate,
};

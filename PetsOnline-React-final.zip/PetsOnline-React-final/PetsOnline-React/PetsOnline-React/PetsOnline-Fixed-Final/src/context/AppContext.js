import React, { createContext, useContext, useState } from 'react';
const AppContext = createContext(null);
export function AppProvider({ children }) {
  const [counter, setCounter] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const add = () => setCounter(c => c + 1);
  const remove = () => setCounter(c => Math.max(0, c - 1));
  const setCategory = (cat) => setSelectedCategory(cat);
  const resetCounter = () => setCounter(0);
  const value = { counter, add, remove, selectedCategory, setCategory, resetCounter };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp debe usarse dentro de AppProvider');
  return ctx;
}

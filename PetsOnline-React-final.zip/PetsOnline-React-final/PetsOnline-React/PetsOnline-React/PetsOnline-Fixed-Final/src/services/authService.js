// Servicio de Autenticación
import apiService from './api';

export const authService = {
  // Login
  login: async (username, password) => {
    const response = await apiService.post('/auth/login', { username, password });
    if (response.token) {
      apiService.setToken(response.token);
    }
    return response;
  },

  // Registro
  register: async (userData) => {
    return apiService.post('/auth/register', userData);
  },

  // Logout
  logout: () => {
    apiService.clearToken();
  },

  // Verificar autenticación
  isAuthenticated: () => {
    return !!localStorage.getItem('jwtToken');
  },

  // Obtener token
  getToken: () => {
    return apiService.getToken();
  },
};

export default authService;

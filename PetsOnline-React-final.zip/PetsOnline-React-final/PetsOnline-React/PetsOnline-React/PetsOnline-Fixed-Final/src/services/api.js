// Servicio de API básico con Axios
// Configuración de cliente HTTP para conectar con el backend Java

// Nota: Para usar este archivo, primero instala axios:
// npm install axios

export class ApiService {
  constructor(baseURL = process.env.REACT_APP_API_URL || 'http://localhost:9090') {
    this.baseURL = baseURL;
    this.token = localStorage.getItem('jwtToken');
  }

  // Headers por defecto
  getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': this.token ? `Bearer ${this.token}` : '',
    };
  }

  // GET request
  async get(endpoint) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'GET',
        headers: this.getHeaders(),
      });
      return await this.handleResponse(response);
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // POST request
  async post(endpoint, data) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(data),
      });
      return await this.handleResponse(response);
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // PUT request
  async put(endpoint, data) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'PUT',
        headers: this.getHeaders(),
        body: JSON.stringify(data),
      });
      return await this.handleResponse(response);
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // DELETE request
  async delete(endpoint) {
    try {
      const response = await fetch(`${this.baseURL}${endpoint}`, {
        method: 'DELETE',
        headers: this.getHeaders(),
      });
      return await this.handleResponse(response);
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Manejar respuesta
  async handleResponse(response) {
    if (response.status === 401) {
      localStorage.removeItem('jwtToken');
      window.location.href = '/login';
    }

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Error en la solicitud');
    }

    return data;
  }

  // Manejar error
  handleError(error) {
    console.error('Error API:', error);
    return error;
  }

  // Establecer token
  setToken(token) {
    this.token = token;
    localStorage.setItem('jwtToken', token);
  }

  // Obtener token
  getToken() {
    return localStorage.getItem('jwtToken');
  }

  // Limpiar token
  clearToken() {
    this.token = null;
    localStorage.removeItem('jwtToken');
  }
}

export default new ApiService();

// Servicio de Productos
import apiService from './api';

export const productService = {
  // Obtener todos los productos
  getAll: () => apiService.get('/api/products'),

  // Obtener producto por ID
  getById: (id) => apiService.get(`/api/products/${id}`),

  // Crear producto
  create: (product) => apiService.post('/api/products', product),

  // Actualizar producto
  update: (id, product) => apiService.put(`/api/products/${id}`, product),

  // Eliminar producto
  delete: (id) => apiService.delete(`/api/products/${id}`),

  // Buscar por nombre
  searchByName: (name) => apiService.get(`/api/products/search?name=${name}`),

  // Buscar por categoría
  getByCategory: (category) => apiService.get(`/api/products/category?category=${category}`),

  // Buscar por rango de precio
  getByPriceRange: (minPrice, maxPrice) =>
    apiService.get(`/api/products/price?minPrice=${minPrice}&maxPrice=${maxPrice}`),

  // Obtener productos en stock
  getInStock: () => apiService.get('/api/products/stock'),
};

export default productService;

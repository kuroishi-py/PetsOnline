import React, { useMemo } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import entities from '../data/entities.mock';
import PetCard from '../components/PetCard';
import Filters from '../components/Filters';
import { useApp } from '../context/AppContext';

export default function Servicios() {
  const { add, selectedCategory, setCategory } = useApp();

  const servicios = entities.filter(e => e.tipo === 'Servicio' || e.tipo === 'Producto');

  const categories = useMemo(() => ['Alimento','Accesorio','Peluqueria','Cuidados','Veterinaria'], []);

  const filtered = servicios.filter(item => {
    if (!selectedCategory || selectedCategory === 'Todos') return true;
    return item.categoria && item.categoria.toLowerCase() === selectedCategory.toLowerCase();
  });

  return (
    <Container>
      <h2>Servicios y Productos</h2>
      <Filters categories={categories} activeCategory={selectedCategory} onChange={setCategory} />
      <Row xs={1} sm={2} md={3} className="g-3">
        {filtered.map(item => (
          <Col key={item.id}>
            <PetCard item={item} onAdd={() => add(item)} />
          </Col>
        ))}
      </Row>
    </Container>
  );
}

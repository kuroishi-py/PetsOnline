import React, { useState } from 'react';
import { Container, Form, Button, Alert } from 'react-bootstrap';
export default function Contact() {
  const [form, setForm] = useState({ nombre: '', correo: '', mensaje: '' });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');
  const validate = () => {
    const e = {};
    if (!form.nombre.trim()) e.nombre = 'El nombre es obligatorio';
    if (!form.correo.trim()) e.correo = 'El correo es obligatorio';
    else {
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!regex.test(form.correo)) e.correo = 'Formato de correo inválido';
    }
    if (!form.mensaje.trim()) e.mensaje = 'El mensaje es obligatorio';
    setErrors(e);
    return Object.keys(e).length === 0;
  };
  const handleSubmit = (ev) => {
    ev.preventDefault();
    setSuccess('');
    if (!validate()) return;
    setSuccess('Mensaje enviado correctamente');
    setForm({ nombre: '', correo: '', mensaje: '' });
    setErrors({});
  };
  return (
    <Container>
      <h2>Contacto</h2>
      {success && <Alert variant="success" role="status">{success}</Alert>}
      <Form onSubmit={handleSubmit} noValidate>
        <Form.Group className="mb-3" controlId="nombre">
          <Form.Label>Nombre</Form.Label>
          <Form.Control
            value={form.nombre}
            onChange={(e) => setForm({ ...form, nombre: e.target.value })}
            isInvalid={!!errors.nombre}
            aria-invalid={!!errors.nombre}
          />
          <Form.Control.Feedback type="invalid">{errors.nombre}</Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3" controlId="correo">
          <Form.Label>Correo</Form.Label>
          <Form.Control
            value={form.correo}
            onChange={(e) => setForm({ ...form, correo: e.target.value })}
            isInvalid={!!errors.correo}
            aria-invalid={!!errors.correo}
          />
          <Form.Control.Feedback type="invalid">{errors.correo}</Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3" controlId="mensaje">
          <Form.Label>Mensaje</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            value={form.mensaje}
            onChange={(e) => setForm({ ...form, mensaje: e.target.value })}
            isInvalid={!!errors.mensaje}
            aria-invalid={!!errors.mensaje}
          />
          <Form.Control.Feedback type="invalid">{errors.mensaje}</Form.Control.Feedback>
        </Form.Group>
        <Button type="submit">Enviar</Button>
      </Form>
    </Container>
  );
}

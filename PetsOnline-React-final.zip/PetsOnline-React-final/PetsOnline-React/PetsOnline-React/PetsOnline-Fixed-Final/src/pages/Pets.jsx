import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button, Form, Spinner } from 'react-bootstrap';
import petService from '../services/petService';

export default function Pets() {
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', type: '', breed: '', age: '' });

  const isAdmin = localStorage.getItem('role') === 'ADMIN';

  const load = async () => {
    setLoading(true);
    try {
      const data = await petService.getAll();
      setPets(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await petService.create({ ...form, age: Number(form.age) });
      setForm({ name: '', type: '', breed: '', age: '' });
      load();
    } catch (err) {
      alert('Error creando mascota');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Eliminar mascota?')) return;
    try {
      await petService.delete(id);
      load();
    } catch (err) {
      alert('Error al eliminar');
    }
  };

  const handleEdit = async (p) => {
    const name = prompt('Nombre', p.name);
    if (name == null) return;
    const age = prompt('Edad', p.age);
    if (age == null) return;
    try {
      await petService.update(p.id, { ...p, name, age: Number(age) });
      load();
    } catch (err) {
      alert('Error al actualizar');
    }
  };

  return (
    <Container className="my-4">
      <h2>Mascotas</h2>
      {isAdmin && (
        <Card className="mb-3">
          <Card.Body>
            <Form onSubmit={handleCreate}>
              <Row className="g-2">
                <Col md>
                  <Form.Control placeholder="Nombre" value={form.name} required onChange={e=>setForm({...form,name:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Tipo" value={form.type} onChange={e=>setForm({...form,type:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Raza" value={form.breed} onChange={e=>setForm({...form,breed:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Edad" value={form.age} onChange={e=>setForm({...form,age:e.target.value})} />
                </Col>
                <Col md="auto">
                  <Button type="submit">Crear</Button>
                </Col>
              </Row>
            </Form>
          </Card.Body>
        </Card>
      )}

      {loading ? <Spinner animation="border" /> : (
        <Row xs={1} sm={2} lg={3} className="g-3">
          {pets.map(p => (
            <Col key={p.id}>
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>{p.name}</Card.Title>
                  <Card.Text>{p.type} - {p.breed}</Card.Text>
                  <div className="d-flex justify-content-between align-items-center">
                    <div>Edad: {p.age}</div>
                    <div>
                      {isAdmin && (
                        <>
                          <Button size="sm" variant="outline-primary" onClick={()=>handleEdit(p)} className="me-2">Editar</Button>
                          <Button size="sm" variant="outline-danger" onClick={()=>handleDelete(p.id)}>Eliminar</Button>
                        </>
                      )}
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </Container>
  );
}

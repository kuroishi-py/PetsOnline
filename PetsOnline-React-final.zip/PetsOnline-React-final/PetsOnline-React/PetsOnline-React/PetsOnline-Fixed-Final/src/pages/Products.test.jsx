import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Products from './Products';

// Mock productService to return deterministic data
jest.mock('../services/productService', () => ({
    __esModule: true,
    default: {
        getAll: jest.fn().mockResolvedValue([
            { id: 1, name: 'Pelota', description: 'Juguete', price: 1000, category: 'Juguetes' },
            { id: 2, name: 'Correa', description: 'Correa resistente', price: 5000, category: 'Accesorios' }
        ]),
        create: jest.fn().mockResolvedValue({}),
        update: jest.fn().mockResolvedValue({}),
        delete: jest.fn().mockResolvedValue({}),
    }
}));

describe('Componente Products', () => {
    test('se monta correctamente y muestra el título', () => {
        render(<Products />);
        expect(screen.getByText(/Productos/i)).toBeInTheDocument();
    });

    test('muestra formulario de creación cuando es ADMIN', () => {
        localStorage.setItem('role', 'ADMIN');
        render(<Products />);
        expect(screen.getByText(/Crear/i)).toBeInTheDocument();
    });
});

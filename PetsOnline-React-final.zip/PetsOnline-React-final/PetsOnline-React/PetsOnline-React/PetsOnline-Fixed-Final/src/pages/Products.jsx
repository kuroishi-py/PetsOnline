import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button, Form, Spinner } from 'react-bootstrap';
import productService from '../services/productService';

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', description: '', category: '', price: '', stock: 0 });

  const isAdmin = localStorage.getItem('role') === 'ADMIN';

  const load = async () => {
    setLoading(true);
    try {
      const data = await productService.getAll();
      setProducts(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await productService.create({ ...form, price: Number(form.price), stock: Number(form.stock) });
      setForm({ name: '', description: '', category: '', price: '', stock: 0 });
      load();
    } catch (err) {
      alert('Error creando producto');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Eliminar producto?')) return;
    try {
      await productService.delete(id);
      load();
    } catch (err) {
      alert('Error al eliminar');
    }
  };

  const handleEdit = async (p) => {
    const name = prompt('Nombre', p.name);
    if (name == null) return;
    const price = prompt('Precio', p.price);
    if (price == null) return;
    try {
      await productService.update(p.id, { ...p, name, price: Number(price) });
      load();
    } catch (err) {
      alert('Error al actualizar');
    }
  };

  return (
    <Container className="my-4">
      <h2>Productos</h2>
      {isAdmin && (
        <Card className="mb-3">
          <Card.Body>
            <Form onSubmit={handleCreate}>
              <Row className="g-2">
                <Col md>
                  <Form.Control placeholder="Nombre" value={form.name} required onChange={e=>setForm({...form,name:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Categoría" value={form.category} onChange={e=>setForm({...form,category:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Precio" value={form.price} required onChange={e=>setForm({...form,price:e.target.value})} />
                </Col>
                <Col md>
                  <Form.Control placeholder="Stock" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})} />
                </Col>
                <Col md="auto">
                  <Button type="submit">Crear</Button>
                </Col>
              </Row>
            </Form>
          </Card.Body>
        </Card>
      )}

      {loading ? <Spinner animation="border" /> : (
        <Row xs={1} sm={2} lg={3} className="g-3">
          {products.map(p => (
            <Col key={p.id}>
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>{p.name}</Card.Title>
                  <Card.Text>{p.description}</Card.Text>
                  <div className="d-flex justify-content-between align-items-center">
                    <div>${Number(p.price).toLocaleString('es-CL')}</div>
                    <div>
                      {isAdmin && (
                        <>
                          <Button size="sm" variant="outline-primary" onClick={()=>handleEdit(p)} className="me-2">Editar</Button>
                          <Button size="sm" variant="outline-danger" onClick={()=>handleDelete(p.id)}>Eliminar</Button>
                        </>
                      )}
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </Container>
  );
}

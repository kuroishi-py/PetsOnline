import React, { useState } from 'react';
import { Container, Form, Button, Card, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import apiService from '../services/api';

const Login = () => {
  const navigate = useNavigate();
  // usar la instancia por defecto exportada desde services/api
  // facilita mocks en tests y coherencia con otros servicios
  
  
  const [credentials, setCredentials] = useState({
    username: '',
    password: ''
  });
  
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setCredentials({
      ...credentials,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Llamar al endpoint de login
      const response = await apiService.post('/auth/login', credentials);
      
      // Guardar el token JWT en localStorage
      localStorage.setItem('jwtToken', response.token);
      localStorage.setItem('username', credentials.username);
      if (response.user && response.user.role) {
        localStorage.setItem('role', response.user.role);
      }
      
      // Redirigir a la página principal
      navigate('/');
      window.location.reload(); // Recargar para actualizar el estado de autenticación
      
    } catch (err) {
      console.error('Error de login:', err);
      setError('Usuario o contraseña incorrectos');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container className="mt-5">
      <div className="d-flex justify-content-center">
        <Card style={{ width: '400px' }}>
          <Card.Body>
            <div className="text-center mb-4">
              <h2>🔐 Iniciar Sesión</h2>
              <p className="text-muted">Accede a tu cuenta de PetsOnline</p>
            </div>

            {error && <Alert variant="danger">{error}</Alert>}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Usuario</Form.Label>
                  <Form.Control
                    type="text"
                    name="username"
                    placeholder="Ingresa tu usuario"
                    value={credentials.username}
                    onChange={handleChange}
                    required
                    autoComplete="username"
                  />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Contraseña</Form.Label>
                <Form.Control
                  type="password"
                  name="password"
                  placeholder="Ingresa tu contraseña"
                  value={credentials.password}
                  onChange={handleChange}
                  required
                  autoComplete="current-password"
                />
              </Form.Group>

              <Button 
                variant="primary" 
                type="submit" 
                className="w-100"
                disabled={loading}
              >
                {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
              </Button>
            </Form>

            <hr />
            
            <div className="text-center">
              <p className="text-muted mb-2">¿No tienes cuenta?</p>
              <Button 
                variant="outline-primary" 
                onClick={() => navigate('/register')}
              >
                Registrarse
              </Button>
            </div>

            <div className="mt-3 p-3 bg-light rounded">
              <small className="text-muted">
                <strong>💡 Datos de prueba:</strong><br />
                Usuario: admin<br />
                Contraseña: admin123
              </small>
            </div>
          </Card.Body>
        </Card>
      </div>
    </Container>
  );
};

export default Login;

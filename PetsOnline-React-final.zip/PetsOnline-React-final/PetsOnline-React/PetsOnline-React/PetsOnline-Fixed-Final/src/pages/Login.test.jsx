jest.mock('../services/api', () => ({
  __esModule: true,
  ApiService: jest.fn().mockImplementation(() => ({
    post: jest.fn().mockResolvedValue({ token: 'dummy-token', user: { role: 'ADMIN' } })
  })),
  default: {
    post: jest.fn().mockResolvedValue({ token: 'dummy-token', user: { role: 'ADMIN' } })
  }
}));

jest.mock('react-router-dom');
import { __mockNavigate as mockedNavigate } from 'react-router-dom';

import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Login from './Login';

describe('Login Component', () => {
  test('renders inputs and allows login flow', async () => {
    render(<Login />);

    const username = screen.getByPlaceholderText(/Ingresa tu usuario/i);
    const password = screen.getByPlaceholderText(/Ingresa tu contraseña/i);
    const btn = screen.getByRole('button', { name: /Iniciar Sesión/i });

    await userEvent.type(username, 'admin');
    await userEvent.type(password, 'admin123');
    await userEvent.click(btn);

    await waitFor(() => expect(localStorage.getItem('jwtToken')).toBe('dummy-token'));
    expect(localStorage.getItem('username')).toBe('admin');
    expect(mockedNavigate).toHaveBeenCalledWith('/');
  });
});

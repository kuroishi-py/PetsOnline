const express = require('express');
const db = require('../db');
const { verifyToken } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', async (req, res) => {
  db.all('SELECT * FROM products', [], (err, rows) => {
    if (err) return res.status(500).json({ message: 'Error al obtener productos' });
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  db.get('SELECT * FROM products WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ message: 'Error al obtener producto' });
    if (!row) return res.status(404).json({ message: 'Producto no encontrado' });
    res.json(row);
  });
});

router.post('/', verifyToken, (req, res) => {
  const { name, description, category, price, stock } = req.body;
  db.run(
    'INSERT INTO products (name, description, category, price, stock) VALUES (?, ?, ?, ?, ?)',
    [name, description, category, price || 0, stock || 0],
    function (err) {
      if (err) return res.status(500).json({ message: 'Error al crear producto' });
      db.get('SELECT * FROM products WHERE id = ?', [this.lastID], (e, row) => res.json(row));
    }
  );
});

router.put('/:id', verifyToken, (req, res) => {
  const { name, description, category, price, stock } = req.body;
  db.run(
    'UPDATE products SET name=?, description=?, category=?, price=?, stock=? WHERE id=?',
    [name, description, category, price, stock, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ message: 'Error al actualizar producto' });
      res.json({ updated: this.changes });
    }
  );
});

router.delete('/:id', verifyToken, (req, res) => {
  db.run('DELETE FROM products WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ message: 'Error al eliminar producto' });
    res.json({ deleted: this.changes });
  });
});

module.exports = router;

const express = require('express');
const db = require('../db');
const { verifyToken } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', (req, res) => {
  db.all('SELECT * FROM pets', [], (err, rows) => {
    if (err) return res.status(500).json({ message: 'Error al obtener mascotas' });
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  db.get('SELECT * FROM pets WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ message: 'Error al obtener mascota' });
    if (!row) return res.status(404).json({ message: 'Mascota no encontrada' });
    res.json(row);
  });
});

router.post('/', verifyToken, (req, res) => {
  const { name, type, breed, age, owner } = req.body;
  db.run(
    'INSERT INTO pets (name, type, breed, age, owner) VALUES (?, ?, ?, ?, ?)',
    [name, type, breed, age || 0, owner || null],
    function (err) {
      if (err) return res.status(500).json({ message: 'Error al crear mascota' });
      db.get('SELECT * FROM pets WHERE id = ?', [this.lastID], (e, row) => res.json(row));
    }
  );
});

router.put('/:id', verifyToken, (req, res) => {
  const { name, type, breed, age, owner } = req.body;
  db.run(
    'UPDATE pets SET name=?, type=?, breed=?, age=?, owner=? WHERE id=?',
    [name, type, breed, age, owner, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ message: 'Error al actualizar mascota' });
      res.json({ updated: this.changes });
    }
  );
});

router.delete('/:id', verifyToken, (req, res) => {
  db.run('DELETE FROM pets WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ message: 'Error al eliminar mascota' });
    res.json({ deleted: this.changes });
  });
});

module.exports = router;

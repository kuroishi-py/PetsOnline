const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();
const SALT_ROUNDS = 10;
const SECRET = process.env.JWT_SECRET || 'change_this_secret_for_prod';

router.post('/register', async (req, res) => {
  const { username, email, password, role } = req.body;
  if (!username || !email || !password) return res.status(400).json({ message: 'Campos incompletos' });
  try {
    const hashed = await bcrypt.hash(password, SALT_ROUNDS);
    db.run(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashed, role || 'USER'],
      function (err) {
        if (err) return res.status(400).json({ message: 'Usuario o email ya existe' });
        return res.json({ id: this.lastID, username, email, role: role || 'USER' });
      }
    );
  } catch (err) {
    return res.status(500).json({ message: 'Error en servidor' });
  }
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ message: 'Credenciales incompletas' });
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err) return res.status(500).json({ message: 'Error en servidor' });
    if (!user) return res.status(401).json({ message: 'Usuario no encontrado' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ message: 'Contraseña incorrecta' });
    const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '2h' });
    return res.json({ token, user: { id: user.id, username: user.username, role: user.role } });
  });
});

module.exports = router;

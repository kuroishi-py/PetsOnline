# Backend local (server)

Este directorio contiene un servidor Express + SQLite usado para evaluación local. Provee autenticación JWT, protección de rutas y endpoints CRUD básicos para `products` y `pets`.

Instrucciones rápidas:

```bash
cd server
npm install
npm run dev   # o npm start
```

El servidor se ejecuta por defecto en `http://localhost:9090`.

Usuario admin por defecto:
- usuario: `admin`
- contraseña: `admin123`

Endpoints principales:
- `POST /auth/register`  -> registrar usuario
- `POST /auth/login`     -> login (devuelve JWT)
- `GET /api/products`    -> listar productos
- `POST /api/products`   -> crear (protegido)
- `PUT /api/products/:id`-> actualizar (protegido)
- `DELETE /api/products/:id` -> eliminar (protegido)
- `GET /api/pets`        -> listar mascotas
- `POST /api/pets`       -> crear (protegido)

Notas:
- La base de datos es un archivo SQLite `data.db` dentro del mismo directorio del servidor.
- El token JWT debe incluirse en el header `Authorization: Bearer <token>` para rutas protegidas.

Este servidor es un scaffold educativo y está pensado para cumplir los criterios de la 3ª evaluación: API REST, DB real, autenticación y manejo de errores.

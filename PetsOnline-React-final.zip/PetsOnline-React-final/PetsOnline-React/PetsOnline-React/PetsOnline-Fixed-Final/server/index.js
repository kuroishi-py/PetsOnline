require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const db = require('./db');

const authRoutes = require('./routes/auth');
const productsRoutes = require('./routes/products');
const petsRoutes = require('./routes/pets');

const app = express();
const PORT = process.env.PORT || 9090;

app.use(cors());
app.use(bodyParser.json());

app.use('/auth', authRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/pets', petsRoutes);

// Health
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Seed an admin user if not exists
const bcrypt = require('bcrypt');
const SALT_ROUNDS = 10;
const adminUser = { username: 'admin', email: 'admin@example.com', password: 'admin123', role: 'ADMIN' };
db.get('SELECT * FROM users WHERE username = ?', [adminUser.username], async (err, row) => {
  if (err) console.error(err);
  if (!row) {
    const hashed = await bcrypt.hash(adminUser.password, SALT_ROUNDS);
    db.run('INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)', [adminUser.username, adminUser.email, hashed, adminUser.role]);
    console.log('Admin user seeded: admin / admin123');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

# 🔌 Guía de Conexión React + Spring Boot Backend

## ✅ Configuración Completada

### 1. Backend (Spring Boot) - Puerto 9090
- ✅ Servidor corriendo en `http://localhost:9090`
- ✅ Base de datos H2 conectada
- ✅ CORS configurado para React (puerto 3000)
- ✅ Endpoints disponibles

### 2. Frontend (React) - Configuración
- ✅ API URL actualizada a `http://localhost:9090`
- ✅ Servicios configurados (productos, mascotas, órdenes, auth)
- ✅ Componente de prueba creado

---

## 🚀 Pasos para Iniciar

### 1. Backend ya está corriendo ✅
Tu backend Spring Boot está activo en: `http://localhost:9090`

### 2. Iniciar React

```powershell
# Navegar al proyecto React
cd "C:\Users\PC RST\Desktop\fulsstack\PetsOnline-React\PetsOnline-Fixed-Final"

# Instalar dependencias (si es primera vez)
npm install

# Iniciar servidor de desarrollo
npm start
```

React se abrirá automáticamente en: `http://localhost:3000`

---

## 📡 Endpoints Disponibles del Backend

### Autenticación
- `POST /auth/login` - Iniciar sesión
- `POST /auth/register` - Registrar usuario

### Productos
- `GET /api/products` - Obtener todos los productos
- `GET /api/products/{id}` - Obtener producto por ID
- `POST /api/products` - Crear producto (requiere auth)
- `PUT /api/products/{id}` - Actualizar producto (requiere auth)
- `DELETE /api/products/{id}` - Eliminar producto (requiere auth)

### Mascotas
- `GET /api/pets` - Obtener todas las mascotas
- `GET /api/pets/{id}` - Obtener mascota por ID
- `POST /api/pets` - Crear mascota (requiere auth)
- `PUT /api/pets/{id}` - Actualizar mascota (requiere auth)
- `DELETE /api/pets/{id}` - Eliminar mascota (requiere auth)

### Órdenes
- `GET /api/orders` - Obtener todas las órdenes
- `GET /api/orders/{id}` - Obtener orden por ID
- `POST /api/orders` - Crear orden (requiere auth)
- `GET /api/orders/user/{userId}` - Órdenes de un usuario

### Usuarios
- `GET /api/users` - Obtener todos los usuarios (requiere auth)
- `GET /api/users/{id}` - Obtener usuario por ID (requiere auth)

---

## 🧪 Probar la Conexión

### Opción 1: Usar el Componente de Prueba

Agrega este componente a tu `App.js`:

```javascript
import TestConnection from './components/TestConnection';

function App() {
  return (
    <div className="App">
      <TestConnection />
    </div>
  );
}

export default App;
```

### Opción 2: Usar la Consola del Navegador

Abre la consola (F12) y ejecuta:

```javascript
// Probar endpoint de productos
fetch('http://localhost:9090/api/products')
  .then(res => res.json())
  .then(data => console.log('Productos:', data))
  .catch(err => console.error('Error:', err));

// Probar endpoint de mascotas
fetch('http://localhost:9090/api/pets')
  .then(res => res.json())
  .then(data => console.log('Mascotas:', data))
  .catch(err => console.error('Error:', err));
```

---

## 💡 Ejemplos de Uso en Componentes React

### Obtener Productos

```javascript
import { useEffect, useState } from 'react';
import productService from '../services/productService';

function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await productService.getAll();
      setProducts(data);
    } catch (error) {
      console.error('Error al cargar productos:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Cargando...</div>;

  return (
    <div>
      <h2>Productos</h2>
      {products.map(product => (
        <div key={product.id}>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
          <p>Precio: ${product.price}</p>
        </div>
      ))}
    </div>
  );
}
```

### Crear Producto

```javascript
import { useState } from 'react';
import productService from '../services/productService';

function CreateProduct() {
  const [product, setProduct] = useState({
    name: '',
    description: '',
    price: 0,
    stock: 0,
    category: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await productService.create(product);
      alert('Producto creado exitosamente');
    } catch (error) {
      console.error('Error:', error);
      alert('Error al crear producto');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Nombre"
        value={product.name}
        onChange={(e) => setProduct({...product, name: e.target.value})}
      />
      {/* Más campos... */}
      <button type="submit">Crear Producto</button>
    </form>
  );
}
```

### Login

```javascript
import { useState } from 'react';
import { ApiService } from '../services/api';

function Login() {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const apiService = new ApiService();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await apiService.post('/auth/login', credentials);
      localStorage.setItem('jwtToken', response.token);
      alert('Login exitoso');
    } catch (error) {
      console.error('Error de login:', error);
      alert('Credenciales inválidas');
    }
  };

  return (
    <form onSubmit={handleLogin}>
      <input
        type="text"
        placeholder="Usuario"
        value={credentials.username}
        onChange={(e) => setCredentials({...credentials, username: e.target.value})}
      />
      <input
        type="password"
        placeholder="Contraseña"
        value={credentials.password}
        onChange={(e) => setCredentials({...credentials, password: e.target.value})}
      />
      <button type="submit">Iniciar Sesión</button>
    </form>
  );
}
```

---

## 🔧 Herramientas Útiles

### 1. Consola H2 (Base de datos)
- URL: `http://localhost:9090/h2-console`
- JDBC URL: `jdbc:h2:mem:tienda_mascotas`
- User: `SA`
- Password: *(vacío)*

### 2. Swagger UI (Documentación API)
- URL: `http://localhost:9090/swagger-ui.html`
- Prueba todos los endpoints desde el navegador

---

## ⚠️ Solución de Problemas

### Error: "Failed to fetch" o "Network Error"

1. **Verifica que el backend esté corriendo:**
   ```powershell
   # Deberías ver: "Started TiendaMascotasBackendApplication"
   ```

2. **Verifica el puerto:**
   - Backend: `http://localhost:9090`
   - React: `http://localhost:3000`

3. **Verifica CORS:**
   El archivo `CorsConfig.java` debe permitir `http://localhost:3000`

### Error: 401 Unauthorized

Los endpoints protegidos requieren autenticación. Primero haz login:

```javascript
// 1. Login
const response = await apiService.post('/auth/login', { username, password });
localStorage.setItem('jwtToken', response.token);

// 2. Ahora puedes acceder a endpoints protegidos
const products = await productService.create(newProduct);
```

### Error: CORS

Si ves errores de CORS, verifica que `CorsConfig.java` incluya:
```java
config.addAllowedOrigin("http://localhost:3000");
```

---

## 📋 Checklist Final

- ✅ Backend corriendo en puerto 9090
- ✅ React configurado con API URL correcta (.env actualizado)
- ✅ CORS configurado en el backend
- ✅ Servicios de API configurados (petService, productService, etc.)
- ⬜ Iniciar React con `npm start`
- ⬜ Probar conexión con el componente TestConnection
- ⬜ Implementar componentes que consuman la API

---

## 🎉 ¡Listo!

Ahora puedes:
1. Iniciar React: `npm start`
2. Acceder a: `http://localhost:3000`
3. Usar los servicios para conectar con el backend
4. Ver datos en tiempo real desde la base de datos H2

¿Necesitas ayuda? Revisa los ejemplos de código arriba o consulta Swagger UI para ver todos los endpoints disponibles.
